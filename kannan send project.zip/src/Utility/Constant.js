// export const baseUrl = 'http://192.168.1.108:8004/clinibuy/'

export const baseUrl = " http://cbe.themaestro.in/ksnm/webservice/"