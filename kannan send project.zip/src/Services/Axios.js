import axios from "axios";
import { baseUrl } from "../Utility/Constant";

const instance = axios.create({
    baseURL:baseUrl
})

export default instance; 